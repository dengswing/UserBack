﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Xml;
using System.IO;

namespace LogServer
{
    public delegate void AppendLogDelegate(string log);
    public delegate void ShowClientInfoDelegate();

    public partial class LogServer : Form
    {
        private int _port;          //server listen port,need add to firewall
        private UdpClient _server;  //server ,used for recieve log
        private IPEndPoint _client; //client ,send data
        private byte[] _buffer;     //recieve data buffer

        private XmlDocument _xmlDoc = new XmlDocument();
        private string _configFileName = "config.xml";

        public LogServer()
        {
            this.SuspendLayout();
            InitializeComponent();
            InitializeEnvironment();
            this.ResumeLayout();
        }

        /// <summary>
        /// 加载配置文件
        /// </summary>
        public void LoadConfig()
        {
            try
            {
                _xmlDoc.Load(_configFileName);

                XmlNode xmlRoot = _xmlDoc.SelectSingleNode("config");
                XmlNode xmlServer = xmlRoot.SelectSingleNode("server");
                XmlNode xmlLayout = xmlRoot.SelectSingleNode("layout");

                //this.cbTopMost.Checked = Convert.ToBoolean(xmlLayout.Attributes["topMost"].Value);

                int x = Convert.ToInt32(xmlLayout.Attributes["x"].Value);
                int y = Convert.ToInt32(xmlLayout.Attributes["y"].Value);
                int w = Convert.ToInt32(xmlLayout.Attributes["w"].Value);
                int h = Convert.ToInt32(xmlLayout.Attributes["h"].Value);

                this.Location = new Point(x, y);
                this.Size = new System.Drawing.Size(w, h);

                _port = int.Parse(xmlServer.Attributes["port"].Value);
            }
            catch (System.Exception ex)
            {
            }
        }

        /// <summary>
        /// 初始化服务器dup环境
        /// </summary>
        private void InitializeEnvironment()
        {
            LoadConfig();

            try
            {
                rtbLog.Clear();
                rtbLog.Focus();

                _server = new UdpClient(_port);
                _client = new IPEndPoint(IPAddress.Any, 0);

                Thread recieveThread = new Thread(Recieve);
                recieveThread.IsBackground = true;
                recieveThread.Start();
            }
            catch (System.Exception ex)
            {
                rtbLog.AppendText(ex.ToString());
            }
        }

        /// <summary>
        /// append log to log viewer
        /// </summary>
        /// <param name="log"></param>
        private void AppendLog(string log)
        {
            if (rtbLog.InvokeRequired)
            {
                AppendLogDelegate d = AppendLog;
                this.Invoke(d,log);
            } 
            else
            {
                rtbLog.AppendText(log);

                if (log.Contains("FATAL") || log.Contains("ERROR") || log.Contains("error") || log.Contains("fatal"))
                {
                    int i = rtbLog.Text.Length;
                    int j = log.Length;
                    int k = i - j;
                    rtbLog.Select(k >0 ? k :0, i);
                    rtbLog.SelectionColor = Color.Red;
                    rtbLog.Select(i-1,0);
                }
                else
                {
                    rtbLog.Focus();
                }
            }
        }

        /// <summary>
        /// 显示客户端信息
        /// </summary>
        private void ShowClientInfo()
        {
            if (lblClientIP.InvokeRequired)
            {
                ShowClientInfoDelegate d = ShowClientInfo;
                this.Invoke(d);
            }
            else
            {
                lblClientIP.Text = _client.Address.ToString();
            }
        }

        /// <summary>
        /// recieve data from client
        /// </summary>
        private void Recieve()
        {
            while (true)
            {
                _buffer = _server.Receive(ref _client);
                string log = Encoding.Default.GetString(_buffer);
                AppendLog(log);
                ShowClientInfo();
            }
        }

        /// <summary>
        /// 保存日志到本地
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "log files (*.log)|*.log|All files (*.*)|*.*";
            sfd.InitialDirectory = "d:/";
            DialogResult dr = sfd.ShowDialog();

            if (dr ==  DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Date:" + DateTime.Now.ToString());
                sb.AppendLine("ClientIP:" + lblClientIP.Text);
                sb.AppendLine("-------------------- Log Start --------------------");
                sb.AppendLine(rtbLog.Text);
                sb.AppendLine("-------------------- Log  End ---------------------");
                File.WriteAllText(sfd.FileName,sb.ToString(),Encoding.UTF8);
            }
        }

        /// <summary>
        /// 清楚显示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClear_Click(object sender, EventArgs e)
        {
            rtbLog.Clear();
        }

        /// <summary>
        /// 设置最上层窗体
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbTopMost_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = cbTopMost.Checked;
        }

        /// <summary>
        /// 窗体关闭保存配置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LogServer_FormClosing(object sender, FormClosingEventArgs e)
        {

            XmlNode xmlRoot = _xmlDoc.SelectSingleNode("config");
            XmlNode xmlLayout = xmlRoot.SelectSingleNode("layout");

            //xmlLayout.Attributes["topMost"].Value = this.cbTopMost.Checked.ToString();

            xmlLayout.Attributes["x"].Value = this.Location.X.ToString();
            xmlLayout.Attributes["y"].Value = this.Location.Y.ToString();
            xmlLayout.Attributes["w"].Value = this.Size.Width.ToString();
            xmlLayout.Attributes["h"].Value = this.Size.Height.ToString();

            _xmlDoc.Save(_configFileName);
        }

        private void cbWrapWord_CheckedChanged(object sender, EventArgs e)
        {
            rtbLog.WordWrap = cbWrapWord.Checked;
        }
    }
}
